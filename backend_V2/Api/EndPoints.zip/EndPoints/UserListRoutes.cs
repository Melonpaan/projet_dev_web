using Core.Models;
using Core.UseCases.Abstractions;
using Microsoft.AspNetCore.Mvc;

namespace Api.EndPoints;

public static class UserListRoutes
{
    public static WebApplication AddUserListRoutes(this WebApplication app)
    {
        var group = app.MapGroup("api/userlist")
            .WithTags("UserList");

        group.MapGet("{userId}", (int userId, IUserListUseCases userListUseCases) =>
        {
            var list = userListUseCases.GetUserLists(userId);
            return Results.Ok(list);
        })
        .WithName("GetUserLists")
        .Produces<IEnumerable<UserList>>(StatusCodes.Status200OK)
        .Produces(StatusCodes.Status500InternalServerError);

        group.MapGet("/{id}", (int id, IUserListUseCases userListUseCases) =>
        {
            var userList = userListUseCases.GetUserListById(id);
            if (userList == null)
                return Results.NotFound();
            return Results.Ok(userList);
        })
        .WithName("GetUserListById")
        .Produces<UserList>(StatusCodes.Status200OK)
        .Produces(StatusCodes.Status404NotFound)
        .Produces(StatusCodes.Status500InternalServerError);

        group.MapPost("", ([FromBody] UserList userList, IUserListUseCases userListUseCases) =>
        {
            userListUseCases.AddToUserList(userList);
            return Results.Ok(new { message = "Film ajouté à la liste de l'utilisateur" });
        })
        .WithName("AddToUserList")
        .Produces<object>(StatusCodes.Status200OK)
        .Produces(StatusCodes.Status400BadRequest)
        .Produces(StatusCodes.Status500InternalServerError);

        group.MapPut("", ([FromBody] UserList userList, IUserListUseCases userListUseCases) =>
        {
            userListUseCases.UpdateUserList(userList);
            return Results.Ok(new { message = "Liste mise à jour avec succès" });
        })
        .WithName("UpdateUserList")
        .Produces<object>(StatusCodes.Status200OK)
        .Produces(StatusCodes.Status400BadRequest)
        .Produces(StatusCodes.Status404NotFound)
        .Produces(StatusCodes.Status500InternalServerError);

        group.MapDelete("{id}", (int id, IUserListUseCases userListUseCases) =>
        {
            userListUseCases.RemoveFromUserList(id);
            return Results.Ok(new { message = "Film retiré de la liste de l'utilisateur" });
        })
        .WithName("RemoveFromUserList")
        .Produces<object>(StatusCodes.Status200OK)
        .Produces(StatusCodes.Status404NotFound)
        .Produces(StatusCodes.Status500InternalServerError);

        return app;
    }
}